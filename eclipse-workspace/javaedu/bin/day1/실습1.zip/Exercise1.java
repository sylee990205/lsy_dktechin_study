package day1;

public class Exercise1 {

	public static void main(String[] args) {
		int num1 = 10;
		int num2 = 25;
		int num3 = 33;
		
		System.out.println("합계 : " + (num1+num2+num3));
		System.out.println("평균 : " + (num1+num2+num3)/3);

	}

}
