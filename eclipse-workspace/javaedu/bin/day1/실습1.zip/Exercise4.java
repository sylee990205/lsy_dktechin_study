package day1;

public class Exercise4 {

	public static void main(String[] args) {
		int number = 100;
		int result;
		
		result = number + 10;
		System.out.println("덧셈 연산의 결과 : " + result);
		
		result = number - 10;
		System.out.println("뺄셈 연산의 결과 : " + result);
		
		result = number * 10;
		System.out.println("곱셈 연산의 결과 : " + result);
		
		result = number / 10;
		System.out.println("나눗셈 연산의 결과 : " + result);

	}

}
