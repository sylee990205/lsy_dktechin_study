package day1;

public class Exercise2 {

	public static void main(String[] args) {
		int num1 = 35;
		int num2 = 10;
		
		System.out.println(num1 +" 를 "+ num2 +" 으로 나눈 결과 몫은 " + (num1/num2) + " 이고 나머지는 "
				+ (num1%num2) + " 입니다.");

	}

}
