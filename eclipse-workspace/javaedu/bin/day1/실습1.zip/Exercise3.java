package day1;

public class Exercise3 {

	public static void main(String[] args) {
		char name1 = '이';
		char name2 = '소';
		char name3 = '영';
		
		System.out.println(name1);
		System.out.println(name2);
		System.out.println(name3);
	}

}
